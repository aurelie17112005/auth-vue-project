<template>
  <v-app>
    <v-app-bar app color="primary" dark>
      <v-toolbar-title>Mon Application</v-toolbar-title>
    </v-app-bar>
    <v-main>
      <!-- Injection des pages via le router -->
      <router-view />
    </v-main>
  </v-app>
</template>

<script>
export default {
  name: 'App'
};
</script>
